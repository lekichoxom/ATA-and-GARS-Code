
// No ©copyright issues
// But we will be happy to see you whenever you use our code(^_^)
// Designed by @BlackX-Lolipop
// Content available by @BlackX-732
// Content available @ https://github.com/BlackX-732/AwesomeMenu
// Version 21.2.7**/
// https://facebook.com/BlackX-732
// https://twitter.com/






$(document).ready(function(){
        $(".sidebar-btn").click(function(){
            $(".wrapper").toggleClass("collapse");
        });
    });